# Алінаті 26 💙

Персональний birthday invitation website.

## Файли

- `index.html` — структура сайту і весь текст
- `style.css` — royal blue / white дизайн
- `script.js` — countdown та scroll-анімації

## Що ще замінити

1. У `index.html` замінити блок `.photo-placeholder` на твоє фото.
2. У `script.js` у `formUrl` вставити посилання на Google Form.
3. За бажанням змінити назву сайту / текст.

## Публікація

Це звичайний static website без npm/build step. Папку можна просто перетягнути в Netlify Drop.
